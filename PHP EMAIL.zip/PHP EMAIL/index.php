<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet" type="text/css" href="css/bootstrap4/css/bootstrap.min.css">

	<title>Sample e-mail</title>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-md-5 mx-auto mt-5 p-5 bg-dark text-white rounded">
			<?php
			if(isset($_SESSION['sent'])){
				echo "<div class='alert alert-success text-center'>".$_SESSION['sent']."</div>";
				
			}

			if(isset($_SESSION['notsent'])){
				echo "<div class='alert alert-success text-center'>".$_SESSION['notsent']."</div>";
			}
			
			?>
			<h1 class="h-1">PHP EMAIL</h1>
			<form action="email.php" method="POST">
			<label>Subject</label>
			<input type="text" class="form-control" name="subject" required placeholder="Message Subject">
			<label>Message</label>
			<textarea class="form-control" name="message" required placeholder="Write your message here"></textarea>
			<label>Email</label>
			<input type="email" class="form-control" name="email" required placeholder="example@gmail.com">
			<button class="btn btn-primary btn-block mt-3" name="send">Send</button>
			</form>
		</div>
	</div>
</div>

	<script type="text/javascript" src="css/bootstrap4/js/bootstrap.min.js"></script>

</body>
</html>